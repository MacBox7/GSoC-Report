__mC, var2 = range(2)

def bar():
    '''
        >>> __mC = 1

        >>> Γ_ = 1
    '''
    pass
