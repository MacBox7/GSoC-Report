__C6__ = 0

C6 = 0

C_6 = 0.

GLOBAL_UPPER_CASE = 0

def bar():
    '''
        >>> Γ1 = 1

        >>> Γ_ = 1

        >>> Γ_1 = 1

        >>> Γ1_ = 1
    '''
    pass
