def foo():
    '''
        >>> class Good():
        ...     pass
    '''
    pass

class ignored:
    pass
