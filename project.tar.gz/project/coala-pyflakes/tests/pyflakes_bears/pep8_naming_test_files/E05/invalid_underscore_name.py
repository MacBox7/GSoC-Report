def foo():
    '''
        >>> class _():
        ...     pass
    '''
    pass
