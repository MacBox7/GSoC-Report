def foo():
    '''
        >>> class Good():
        ...     class bad():
        ...          pass
    '''
    pass
