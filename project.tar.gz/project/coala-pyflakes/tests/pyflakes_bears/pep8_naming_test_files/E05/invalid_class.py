def foo():
    '''
        >>> class bad():
        ...     pass
    '''
    pass
