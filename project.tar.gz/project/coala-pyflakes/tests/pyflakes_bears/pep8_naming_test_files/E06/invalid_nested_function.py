def foo():
    '''
        >>> def ok():
        ...     def NotOk():
        ...         pass
    '''
    pass
