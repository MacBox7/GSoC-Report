def foo():
    '''
        >>> def NotOk():
        ...     pass
    '''
    pass
