def foo():
    '''
        >>> def ok():
        ...     pass
        >>> def _ok():
        ...     pass
        >>> def ok_ok_ok_ok():
        ...     pass
        >>> def _somehow_good():
        ...     pass
        >>> def go_od_():
        ...     pass
        >>> def _go_od_():
        ...     pass
        >>> def go_od_():
        ...     pass
        >>> def go_od_():
        ...     pass
        >>> def go_od_():
        ...     pass
    '''
    pass

def bar():
    '''
        >>> class Good():
        ...    def _method(self):
        ...        pass
        ...    def __method__(self):
        ...        pass
    '''
    pass

def foo_bar():
    '''
        >>> class TestCase():
        ...    def setUp(self):
        ...        pass
        ...    def tearDown(self):
        ...        pass
        ...    def setUpClass(self):
        ...        pass
        ...    def tearDownClass(self):
        ...        pass
    '''
    pass
