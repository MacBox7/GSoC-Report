class Foo:
    lowercase = 0

def bar():
    '''
        >>> class Foo(FooParent):
        ...     _1 = 0
    '''
    pass
