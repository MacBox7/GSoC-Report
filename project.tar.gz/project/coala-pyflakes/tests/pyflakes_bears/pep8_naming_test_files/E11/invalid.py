class Foo:
    [mix_Case, var2] = range(2)

def bar():
    '''
        >>> class Foo():
        ...     mix_Case = 0
    '''
    pass
