def foo():
    '''
        >>> from mod import CamelCase as CONST
    '''
    pass
