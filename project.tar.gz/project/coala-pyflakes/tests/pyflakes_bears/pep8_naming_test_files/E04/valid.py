def foo():
    '''
        >>> from mod import Good as Good
    '''
    pass  # Ignore PyUnusedCodeBear
