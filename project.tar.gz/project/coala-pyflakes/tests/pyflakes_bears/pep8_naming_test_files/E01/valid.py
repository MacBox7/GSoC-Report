import good as good
import OK as GOOD
import GOOD as ignored

def foo():
    '''
        >>> from mod import GOOD as GOOD
    '''
    pass
