def foo():
    '''
        >>> import GOOD as bad
    '''
    pass
