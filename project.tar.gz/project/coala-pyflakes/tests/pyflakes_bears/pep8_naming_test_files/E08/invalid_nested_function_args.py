def foo():
    '''
        >>> class Good():
        ...     def __str__(self):
        ...         def good(BAD):
        ...             pass
    '''
    pass

class Foo:
    def good(self):
        def bar(VERYBAD):
            pass
