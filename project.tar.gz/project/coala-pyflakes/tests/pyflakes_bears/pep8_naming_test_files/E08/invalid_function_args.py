def foo(BAD):
    '''
        >>> def bar(VERYBAD):
        ...     pass
    '''
