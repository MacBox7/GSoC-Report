class Foo:
    def bar(me):
        pass

def foo_bar():
    '''
        >>> class Foo(FooParent):
        ...     def bar():
        ...         pass
    '''
    pass
