def foo():
    '''
        >>> from mod import GoodFile as bad
    '''
    pass
