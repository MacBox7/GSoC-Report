def foo():
    '''
        >>> from mod import CamelCase as CamelCase
    '''
    pass
