def foo():
    '''
        >>> class Good():
        ...     def __str__(self):
        ...         def __bar():
        ...             pass
    '''
    pass
