def __bad():
    pass

def foo():
    '''
        >>> def __bad():
        ...     pass
    '''
    pass
