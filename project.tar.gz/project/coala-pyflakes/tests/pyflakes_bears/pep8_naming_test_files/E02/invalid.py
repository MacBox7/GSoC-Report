def foo():
    '''
        >>> from mod import good as Bad
    '''
    pass
