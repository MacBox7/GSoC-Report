def foo():
    '''
        >>> from mod import good as bad
    '''
    pass
