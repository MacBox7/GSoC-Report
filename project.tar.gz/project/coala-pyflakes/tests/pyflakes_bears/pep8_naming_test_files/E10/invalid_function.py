class Foo:
    @classmethod
    def bar(self):
        pass

def foo_bar():
    '''
        >>> class Foo(FooParent):
        ...     @classproperty
        ...     def bar(self):
        ...         pass
    '''
    pass
