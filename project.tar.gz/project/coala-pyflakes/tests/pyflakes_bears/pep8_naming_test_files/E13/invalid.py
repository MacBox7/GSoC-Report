def foo():
    Var1 = 0

def bar():
    '''
        >>> def foo():
        ...    [Var1, var2] = range(2)
    '''
    pass
